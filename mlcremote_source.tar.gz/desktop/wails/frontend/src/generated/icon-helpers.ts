export const getIcon = (name: string) => 'icon-' + name;
export const getIconForShell = () => 'icon-terminal';
export const getIconForDir = () => 'icon-folder';
