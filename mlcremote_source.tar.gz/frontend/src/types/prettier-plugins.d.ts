declare module 'prettier/standalone' {
  const prettier: any
  export default prettier
}

declare module 'prettier/parser-babel'
declare module 'prettier/parser-typescript'
declare module 'prettier/parser-yaml'
declare module 'prettier/parser-html'
declare module 'prettier/parser-postcss'
declare module 'prettier-plugin-toml'
declare module 'prettier-plugin-xml'

declare module 'prettier/*'
