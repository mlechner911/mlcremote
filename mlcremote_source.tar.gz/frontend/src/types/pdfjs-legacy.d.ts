declare module 'pdfjs-dist/legacy/build/pdf' {
  const anyExport: any
  export = anyExport
}

declare module 'pdfjs-dist/*' {
  const anyExport: any
  export = anyExport
}
