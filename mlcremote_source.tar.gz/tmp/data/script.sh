#!/bin/bash
echo "Hello from bash"
ls -la
